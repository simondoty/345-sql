ASP ?>>[CLEAR].
ASP_PATH /cygwin/home/Francisco/newJython/rel_ut/trunk/gringo SOLVER /cygwin/home/Francisco/newJython/rel_ut/trunk/clasp

print "#############################   Diners Problem   #############################"
#ASP ?[dinersASP.lp].
print "Original Database"
ASP PRINT
print "##############################################################################"

ASP ?->'male'('b').	
ASP ?->'person'('a').
ASP PRINT
#Printing results of diners'
x=ASP ?-.
for i in x:
    print i

#ASP ?>>[CLEAR]. 
