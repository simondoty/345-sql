README file for SQL Subquery Addition to REL
Group: Simon Doty, Ethan Petuchowski, Justin Hust

Instructions:

Unzip zipped folder.

Copy files into apprpriate directories within REL / jython.
Files includes in zip: Python.g, SQLVisitor.java, SQLValidator.java, and tests/

Run 'ant' at command line to build REL with our updated files.

To run our test cases, while in the root of jython,
enter 'dist/bin/jython tests/demo#.py where # is the number of the test that
you wish to run. There are 9 tests, and in genral they increase with complexity 
the closer to 9 you get.

Note that we have hard coded in Ethan's database information into our demo.py
connect statements (in each demo), and also in Python.g. So to change user accounts,
these will need to be updated and the tables will need to be filled. 


